<template>
   <div class="container">    
    <ShoppingCart />
  </div>
</template>

<script>
import ShoppingCart from './components/ShoppingCart';


export default {
  name: 'app',
  components: {
    ShoppingCart
  }
}

</script>

<style>

</style>
