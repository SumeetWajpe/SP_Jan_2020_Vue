import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
        isAuthenticated:false
  },  
  actions: {
    setAuthentication:({commit})=>{
        commit('authenticate');
    }
  },
  mutations: {
    authenticate:(state)=>{
        state.isAuthenticated = true;
    }
  },
});

export default store;