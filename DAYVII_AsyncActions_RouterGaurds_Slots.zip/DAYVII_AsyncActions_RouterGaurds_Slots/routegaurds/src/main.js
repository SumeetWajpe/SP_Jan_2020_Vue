import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router';
import About from "./components/About";
import Contact from "./components/Contact";
import Dashboard from "./components/Dashboard";
import Login from "./components/Login";
import store from './store/store';

Vue.config.productionTip = false
Vue.use(VueRouter);

const routes = [ 
  {path:'/dashboard',component:Dashboard ,name:'dashboard',
  children:[
    {path:'',component:About},
    {path:'contact',component:Contact,name:'contact'}
  ], 
  // beforeEnter(to,from,next){
  //   if(store.state.isAuthenticated == false){
  //     next('/');
  //   }else{
  //     next(); // as planned (dashboard)
  //   }
  // }
},
{path:'/',component:Login},
];

var router = new VueRouter({
  routes,
  mode:'history'
});


new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
