<template>
    <div>
        <h1> Contact </h1>
        <ContactCard>
            <template v-slot:heading>
                <h1>Heading set from Contact </h1>           
            </template>
            <template v-slot:main>
                 <strong> Main Contact set from Contact </strong>           
            </template>
             <template v-slot:footer>
                <p>@footer from Contact </p>         
            </template>           
        </ContactCard>
        <hr/>
         <ContactCard>
            <template v-slot:heading>
                <h1>Heading set from Contact 2 </h1>           
            </template>           
             <template v-slot:footer>
                <p>@footer from Contact 2 </p>         
            </template>           
        </ContactCard>
    </div>
</template>

<script>
import ContactCard from './contactcard';
    export default {
        components:{
            ContactCard
        }
    }
</script>

<style scoped>

</style>