<template>
    <div>
        <h1>dashboard </h1>
        <router-view :key="$router.path"></router-view>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>