<template>
    <div>
        <h1>Login </h1>
        Username : <input type="text" v-model="user.username" /> <br/>
        Password : <input type="text" v-model="user.password" />
        <input type="button" value="Login"  @click="login" />

    </div>
</template>

<script>
    export default {
        data(){
           return {
                user:{
                    username:'',
                    password:''
            }            
           }
        },
        methods:{
            login(){
                // perform authentication !
                // if(this.user.username === 'admin' && this.user.password === 'admin'){
                //     // isAuth -> true !
                //     this.$store.dispatch('setAuthentication');
                //      this.$router.replace('/dashboard');
                //     // this.$router.replace({name:'dashboard'}); //not working !

                // }
            }
        }
    }
</script>

<style scoped>

</style>