<template>
    <div>
        <!-- <div class="header">
            <h2>Heading for Contact ! </h2>
        </div>
        <div class="main">
            <strong> Main of Contact </strong>
        </div>
        <div class="footer">
            @footer of contact
        </div> -->

<!-- Default slot ! -->
        <!-- <slot></slot> -->
<!-- Named Slot -->
        <slot name="heading"></slot>
        <slot name="main"></slot>
        <slot name="footer"></slot>


    </div>
</template>

<script>
    export default {
        name:'ContactCard'
    }
</script>

<style scoped>

</style>