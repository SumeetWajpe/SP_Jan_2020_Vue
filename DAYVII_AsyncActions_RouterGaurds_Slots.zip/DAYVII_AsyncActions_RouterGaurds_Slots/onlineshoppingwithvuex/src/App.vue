<template>
  <div class="container">
    
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
      <ul class="navbar-nav">
        <li class="nav-item">         
          <router-link to="/" class="nav-link">Cart</router-link>
        </li>
        <li class="nav-item">
            <router-link to="/posts" class="nav-link">Posts</router-link>
        </li>  
         <li class="nav-item">
            <router-link to="/nestedposts" class="nav-link">Nested Posts</router-link>
        </li>        
      </ul>
    </nav>
    <router-view></router-view>
  </div>
</template>

<script>
// import ShoppingCart from './components/ShoppingCart';
// import Posts from './components/posts'
// import 'bootstrap-icons';

export default {
  name: "app",
  components: {},
};
</script>

<style>
</style>
