<template>
<div>   
      <div class="jumbotron">
        <h1>  Online Shopping </h1>  
      </div>
    <TotalProducts />
        <div class="row">
            <div class="col-md-4" v-for="product in allProducts" :key="product.id">
            <Product :productdetails="product"  />
        </div>
        </div>
    </div>
</template>

<script>
import Product from './Product';
import TotalProducts from './totalproducts'
 import { mapGetters} from 'vuex';

export default {
    name: 'ShoppingCart',
    components: {
        Product,TotalProducts
    },    
    computed:{
        ...mapGetters(['allProducts'])
    },
    methods:{
      
    }
}
</script>

<style>

</style>
