<template>
    <div>
        <h1> Products Count : {{$store.state.products.length}} </h1>
    </div>
</template>

<script>
    export default {
        name:'TotalProducts'
    }
</script>

<style scoped>

</style>