<template>
    <div>
        <div class="jumbotron">
            <h1>Post Details for {{postId}}</h1>
        </div>
        <hr/>
        <strong>Post Id :</strong> {{thePost.id}} <br/>
        <strong>User Id :</strong> {{thePost.userId}} <br/>
        <strong>Title :</strong> {{thePost.title}} <br/>
        <strong>Body :</strong> {{thePost.body}} <br/>

    <button class="btn btn-success" @click="GoBack">Back to Posts</button>
    </div>
</template>

<script>
import axios from 'axios';

    export default {
        name:'PostDetails',
        data(){
            return {
                postId: this.$route.params.id,
                thePost:{}
            }
        },
        methods:{
            GoBack(){
                this.$router.back();
            }
        },        
        mounted(){
             // ajax request
      axios.get('https://jsonplaceholder.typicode.com/posts/'+this.$route.params.id)
      .then((response)=> this.thePost = response.data,(err)=>console.log(err))

        }
    }
</script>

<style scoped>

</style>