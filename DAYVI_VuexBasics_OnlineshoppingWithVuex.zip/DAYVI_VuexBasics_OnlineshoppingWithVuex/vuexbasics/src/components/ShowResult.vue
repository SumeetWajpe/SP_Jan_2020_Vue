<template>
    <div>
        <hr/>
        <h2>Global Count : {{getCurrentCount}} </h2>
    </div>
</template>

<script>
import { mapGetters} from 'vuex';

    export default {
        name:'ShowResult',
         computed:{
            ...mapGetters(['getCurrentCount'])
        },
    }
</script>

<style scoped>

</style>