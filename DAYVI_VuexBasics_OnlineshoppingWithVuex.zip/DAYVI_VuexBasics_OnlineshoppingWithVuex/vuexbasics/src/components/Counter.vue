<template>
    <div>
        <h2>Counter </h2>
        <strong>Current Count is : {{getCurrentCount}} </strong>
        <button @click="increment(50)">
            ++
        </button>
         <button @click="incrementAsync(100)">
            Async++
        </button>
    </div>
</template>

<script>
import {mapActions, mapGetters} from 'vuex';

    export default {
        name:'Counter'   ,
        computed:{
            ...mapGetters(['getCurrentCount'])
        },
        methods:{
            // increment(){
            //     // dispatch an action ?
            //     this.$store.dispatch('increment')
            // }

            ...mapActions(['increment','incrementAsync'])
        }

    }
</script>

<style scoped>

</style>