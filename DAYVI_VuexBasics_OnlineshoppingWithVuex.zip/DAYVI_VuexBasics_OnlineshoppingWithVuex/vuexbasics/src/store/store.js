import Vue from 'vue';
import  Vuex from 'vuex';

Vue.use(Vuex);

//store

export const store = new Vuex.Store({
    state:{
        count:0//global data
    },
    getters:{
        getCurrentCount:state=>{
            return state.count;
        }
    },
    actions:{
        increment:({commit},payload)=>{
            commit('incrementcount',payload)
        },
        incrementAsync:({commit},payload)=>{
            setTimeout(function(){
                commit('incrementcount',payload)
            },3000)
        }
    },
    mutations:{
        incrementcount:(state,payload)=>{
            if(payload >=50){
                state.count+=payload;
            }else{
                state.count++;
            }
        }
    }
})