import Vue from 'vue'
import App from './App.vue';
import VueRouter from 'vue-router';
import ShoppingCart from './components/ShoppingCart';
import Posts from './components/posts';
import PostDetails from './components/postdetails';
import NestedPosts from './components/nestedposts';
import Message from './components/message';
import {store} from './store/store';

Vue.config.productionTip = false

Vue.use(VueRouter);

// routes
const routes = [
  {path:'/',component:ShoppingCart},
  {path:'/posts',component:Posts},
  {path:'/nestedposts',
    component:NestedPosts,
    children:[
      {path:'',component:Message},
      {path:'details/:id',component:PostDetails,name:'details'}
    ]
  },
  {path:'/postdetails/:id',component:PostDetails,name:'postdetails'}

];

var router = new VueRouter({
  routes,
  mode:'history'
});

Vue.filter('outofstock',function(value,args){
  switch(value){
    case 0:
      return 'Out Of Stock';
      case 1:
        return value + args.substring(0,args.length-1)
    default:
      return value + ' ' + args;
  }
});

new Vue({
  store,
  router,
  render: h => h(App)  
}).$mount('#app')
