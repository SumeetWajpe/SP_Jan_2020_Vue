import Addition, {Product} from './MathModule.js'
console.log(Addition(20,30));
console.log(Product(20,30));
