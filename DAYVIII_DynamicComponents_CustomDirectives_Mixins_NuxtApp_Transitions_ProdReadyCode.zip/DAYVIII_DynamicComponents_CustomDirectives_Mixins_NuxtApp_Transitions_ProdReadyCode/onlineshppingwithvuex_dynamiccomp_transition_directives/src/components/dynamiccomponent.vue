<template>
  <div>
    <input
      type="button"
      value="Udemy"
      class="btn btn-primary"
      @click="componentToBeCreated = 'udemy'"
    />
    {{ " " }}
    <input
      type="button"
      value="Pluralsight"
      class="btn btn-primary"
      @click="componentToBeCreated = 'plural'"
    />
     <transition name="bounce">
    <keep-alive>     
        <component :is="componentToBeCreated"> </component>     
    </keep-alive>
     </transition>
  </div>
</template>

<script>
import Udemy from "./udemy";
import Pluralsight from "./pluralsight";
export default {
  name: "DynamicComponent",
  components: { udemy: Udemy, plural: Pluralsight },
  data() {
    return {
      componentToBeCreated: "udemy",
    };
  },
};
</script>
<style scoped>
.bounce-enter-active{
    animation: bounce-in 1s;
}
.bounce-leave-active{
    animation: bounce-in 1s reverse;
}
@keyframes bounce-in {
    0%{transform:scale(0)}
    50%{transform:scale(1.2)}
    100%{transform:scale(1)}
}
</style>