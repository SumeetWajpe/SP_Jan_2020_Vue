<template>
    <div>
        <Udemy />
        <Pluralsight />
    </div>
</template>

<script>
import Udemy from './udemy';
import Pluralsight from './pluralsight'
    export default {
        name:'CoursePlatforms',
        components:{
            Udemy,
            Pluralsight
        }
    }
</script>

<style scoped>

</style>