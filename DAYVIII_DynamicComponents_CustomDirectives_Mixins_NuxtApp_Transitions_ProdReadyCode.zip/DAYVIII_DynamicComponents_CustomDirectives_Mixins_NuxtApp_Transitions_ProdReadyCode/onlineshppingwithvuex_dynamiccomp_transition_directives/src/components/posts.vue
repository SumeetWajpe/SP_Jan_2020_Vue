<template>
  <div>
    <div class="jumbotron">
      <h1>All Posts</h1>     
    </div>
     <ul>
          <li v-highlight:background.delayed="{maincolor:'lightgray',delayby:3000}"  v-for="post in $store.state.posts" :key="post.id">
             <!-- <router-link to="/postdetails" >{{post.title}} </router-link> -->
             <router-link :to="{name:'postdetails',params:{id:post.id } }" >{{post.title}} </router-link>
          </li>
      </ul> 
  </div>
</template>

<script>
export default {
  name: "Posts",  
  mounted(){
     // dispatch an action
     this.$store.dispatch('fetchposts');
  }
};
</script>

<style scoped>
</style>