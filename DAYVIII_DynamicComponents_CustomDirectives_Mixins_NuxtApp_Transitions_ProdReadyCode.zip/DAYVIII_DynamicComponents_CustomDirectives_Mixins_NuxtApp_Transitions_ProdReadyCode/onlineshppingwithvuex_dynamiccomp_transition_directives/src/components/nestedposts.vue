<template>
  <div>
    <div class="jumbotron">
      <h1>All Posts</h1>
    </div>
    <div class="row">
      <div class="col-md-6 bordered">
        <ul>
          <li v-for="post in allPosts" :key="post.id">
            <!-- <router-link to="/postdetails" >{{post.title}} </router-link> -->
            <router-link :to="{ name: 'details', params: { id: post.id } }"
              >{{ post.title }}
            </router-link>
          </li>
        </ul>
      </div>
      <div class="col-md-5 bordered">
        <router-view :key="$route.path"></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "NestedPosts",
  data() {
    return {
      allPosts: [],
    };
  },
  mounted() {
    // ajax request
    axios.get("https://jsonplaceholder.typicode.com/posts").then(
      (response) => (this.allPosts = response.data),
      (err) => console.log(err)
    );
  },
  watch: {
    //   $route(to,from){
    //       if(to !== from){
    //           location.reload();
    //       }
    //   }
  },
//   beforeRouteUpdate(to, from, next) {
//     if (to !== from) {       
//         next();
//     }
//   },
};
</script>

<style scoped>
.bordered {
  border: 1px solid gray;
  border-radius: 5px;
  margin: 10px;
}
</style>