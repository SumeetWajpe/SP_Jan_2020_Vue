<template>
    <div>
        <div class="jumbotron">
            <h1>Post Details for {{postId}}</h1>
        </div>
        <hr/>
        <strong>Post Id :</strong> {{thePost.id}} <br/>
        <strong>User Id :</strong> {{thePost.userId}} <br/>
        <strong>Title :</strong> {{thePost.title}} <br/>
        <strong>Body :</strong> {{thePost.body}} <br/>

    <button class="btn btn-success" @click="GoBack">Back to Posts</button>
    </div>
</template>

<script>
    export default {
        name:'PostDetails',
        data(){
            return {
                postId: this.$route.params.id,
                thePost:{}
            }
        },
        methods:{
            GoBack(){
                this.$router.back();
            }
        },        
        mounted(){
          let index = this.$store.state.posts.findIndex((p) => p.id === this.postId);
          this.thePost = this.$store.state.posts[index];

        }
    }
</script>

<style scoped>

</style>