<template>
    <div>
          <h1>Pluralsight</h1>
  Enter Course : <input type="text" v-model="filterText"/>
        <ul>
            <li v-for="course in filterCourses" :key="course">{{course}}</li>
        </ul>
        <input type="button" value="Add" @click="courses.push('Typescript')" />
    </div>
</template>

<script>
import {courseMixin} from '../mixin/coursemixin';

    export default {
        name:'Pluralsight',  
        data(){
            return {
                courses:['C','C++','C#']
            }
        },
        mixins:[courseMixin]
        
    }
</script>

<style scoped>

</style>