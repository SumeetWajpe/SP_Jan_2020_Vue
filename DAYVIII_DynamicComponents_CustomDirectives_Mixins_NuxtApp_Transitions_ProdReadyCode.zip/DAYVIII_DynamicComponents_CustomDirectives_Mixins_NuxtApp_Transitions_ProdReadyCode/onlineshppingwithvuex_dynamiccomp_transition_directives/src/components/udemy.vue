<template>
    <div>
        <h1>Udemy</h1>
        Enter Course : <input type="text" v-model="filterText"/>
        <ul>
            <li v-for="course in filterCourses" :key="course">{{course}}</li>
        </ul>
    </div>
</template>

<script>
import {courseMixin} from '../mixin/coursemixin';

    export default {
        name:'Udemy',
        mixins:[courseMixin]        
    }
</script>

<style scoped>

</style>