import Vue from 'vue'
import App from './App.vue';
import VueRouter from 'vue-router';
import ShoppingCart from './components/ShoppingCart';
import Posts from './components/posts';
import PostDetails from './components/postdetails';
import NestedPosts from './components/nestedposts';
import Message from './components/message';
import {store} from './store/store';
import CoursePlatforms from './components/coursesplatforms';
import DynamicComponent from './components/dynamiccomponent';



Vue.config.productionTip = false

Vue.use(VueRouter);

// routes
const routes = [
  {path:'/',component:ShoppingCart},
  {path:'/courses',component:CoursePlatforms},
  {path:'/dynamic',component:DynamicComponent},

  {path:'/posts',component:Posts},
  {path:'/nestedposts',
    component:NestedPosts,
    children:[
      {path:'',component:Message},
      {path:'details/:id',component:PostDetails,name:'details'}
    ]
  },
  {path:'/postdetails/:id',component:PostDetails,name:'postdetails'}

];

var router = new VueRouter({
  routes,
  mode:'history'
});

Vue.filter('outofstock',function(value,args){
  switch(value){
    case 0:
      return 'Out Of Stock';
      case 1:
        return value + args.substring(0,args.length-1)
    default:
      return value + ' ' + args;
  }
});

Vue.directive('highlight',{
  bind(el,binding){ // when directive is attached to the dom !
    if(binding.modifiers['delayed']){
      setTimeout(()=>{
        if(binding.arg == "background"){
          el.style.backgroundColor = binding.value.maincolor
        }else{
          el.style.border = "1px solid blue"
        }
      },binding.value.delayby)
    }
  }
})

new Vue({
  store,
  router,
  render: h => h(App)  
}).$mount('#app')
