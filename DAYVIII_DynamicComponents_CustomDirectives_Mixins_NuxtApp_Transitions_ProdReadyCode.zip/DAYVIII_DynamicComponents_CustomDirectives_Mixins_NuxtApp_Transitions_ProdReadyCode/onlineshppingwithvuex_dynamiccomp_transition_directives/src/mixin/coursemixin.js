export const courseMixin = {
    data(){
        return {
            courses:['HTML5','CSS3','React','Redux'],  
            filterText:''              
        }
    },
    computed:{
        filterCourses(){
            return this.courses.filter(c=>c.match(this.filterText))
        }
    }
}