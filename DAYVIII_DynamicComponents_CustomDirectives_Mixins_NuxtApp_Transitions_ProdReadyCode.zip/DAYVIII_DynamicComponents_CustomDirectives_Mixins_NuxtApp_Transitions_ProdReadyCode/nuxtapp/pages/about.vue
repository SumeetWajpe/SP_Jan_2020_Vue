<template>
    <div>
        <Logo />    
        <h1> ABout Page ! </h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>