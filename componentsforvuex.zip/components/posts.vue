<template>
  <div>
    <div class="jumbotron">
      <h1>All Posts</h1>     
    </div>
     <ul>
          <li v-for="post in allPosts" :key="post.id">
             <!-- <router-link to="/postdetails" >{{post.title}} </router-link> -->
             <router-link :to="{name:'postdetails',params:{id:post.id } }" >{{post.title}} </router-link>

          </li>
      </ul> 
  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: "Posts",
  data(){
      return {
          allPosts:[]
      }
  },
  mounted(){
      // ajax request
      axios.get('https://jsonplaceholder.typicode.com/posts')
      .then((response)=> this.allPosts = response.data,(err)=>console.log(err))
  }
};
</script>

<style scoped>
</style>