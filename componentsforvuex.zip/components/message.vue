<template>
    <div>
        <strong>Click on a post to see the details !</strong>
    </div>
</template>

<script>
    export default {
        name:'Message'
    }
</script>

<style scoped>

</style>