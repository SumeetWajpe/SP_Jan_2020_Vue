<template>
  <div>
    <div class="jumbotron">
      <h1>All Posts</h1>     
    </div>
     <ul>
          <li v-for="post in allPosts" :key="post.id">{{post.title}}</li>
      </ul>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: "Posts",
  data(){
      return {
          allPosts:[]
      }
  },
  mounted(){
      // ajax request
      axios.get('https://jsonplaceholder.typicode.com/posts')
      .then((response)=> this.allPosts = response.data,(err)=>console.log(err))
  }
};
</script>

<style scoped>
</style>