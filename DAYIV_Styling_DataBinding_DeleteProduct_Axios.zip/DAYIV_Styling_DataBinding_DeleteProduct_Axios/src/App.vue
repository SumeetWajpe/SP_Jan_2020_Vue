<template>
   <div class="container">    
    <ShoppingCart />
    <Posts />
  </div>
</template>

<script>
import ShoppingCart from './components/ShoppingCart';
import Posts from './components/posts'
// import 'bootstrap-icons';

export default {
  name: 'app',
  components: {
    ShoppingCart,
    Posts
  }
}

</script>

<style>

</style>
