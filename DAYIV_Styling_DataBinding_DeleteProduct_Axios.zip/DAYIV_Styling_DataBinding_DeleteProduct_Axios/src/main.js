import Vue from 'vue'
import App from './App.vue';


Vue.config.productionTip = false


Vue.filter('outofstock',function(value,args){
  switch(value){
    case 0:
      return 'Out Of Stock';
      case 1:
        return value + args.substring(0,args.length-1)
    default:
      return value + ' ' + args;
  }
})


new Vue({
  render: h => h(App),
}).$mount('#app')
